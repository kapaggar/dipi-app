# Official references

Checked2026-09-09. These sources support verification technique; the repository and owner decisions remain product authority. Do not upgrade pinned dependencies just because documentation includes newer APIs.

- [Android Compose accessibility defaults](https://developer.android.com/develop/ui/compose/accessibility/api-defaults): minimum48dp interactive targets, target-overlap risks, built-in semantics and meaningful action descriptions. Verify actual clickable bounds; a visually small icon may have expanded hit bounds that overlap a neighbor.
- [Android Compose accessibility testing](https://developer.android.com/develop/ui/compose/accessibility/testing): combine automated checks and manual assistive-technology inspection. Check API availability against the existing Compose dependency before adding an accessibility-testing library.
- [Android HTML printing](https://developer.android.com/training/printing/html-docs): print through the Android WebView adapter after page loading. Its pagination capabilities differ from desktop browser printing; page counts and CSS behavior require actual Android print output.
- [W3C contrast minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html): use4.5:1 for ordinary text and 3:1 for large text. Measure composited colors; rounded sample ratios in a design document do not prove every rendered element passes.
- [W3C non-text contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html): check meaningful control/state boundaries separately from decorative hairlines.

No assertion of full WCAG conformance or legal compliance is made by this planning package. The ratios are concrete quality checks, not a substitute for testing the complete user flow.
