package org.dhamma.dipi.staff.course

/** Native-screen dispatch for a desk tile, in place of the fragile title-string match. */
enum class DeskTileAction { CentreOps, AppSettings, AdvancedSearch, CourseReport }

data class DeskTileSpec(
    val title: String,
    val route: String,
    val action: DeskTileAction? = null,
    /** SheetExport label when the chip fetches a real export instead of the placeholder. */
    val sheet: String? = null,
    /**
     * A one-release affordance on a tile that just moved (v5 T3 moved Course
     * report off the Board). It comes off in the next MINOR — do not leave it
     * on a tile the desk has had for a while.
     */
    val isNew: Boolean = false,
)

enum class CourseHubLive { Applications, Summary, Photos, Audit, Calling, ZeroDay, CentreOps }

data class CourseHubTile(
    val title: String,
    val route: String,
    val live: CourseHubLive? = null,
    /** Header glyph on the phone hub cards (native tiles only). */
    val glyph: String = "",
)

/**
 * Native tiles lead — they are what the registrar touches — then the
 * desk-site links in their existing order (owner feedback 2026-08-27). The
 * Centre Settings desk-site route is kept for reference but unused once
 * `action` is set; the native screen replaces it rather than duplicating it.
 *
 * Manage Courses, Daily Activity and SMS Report were retired from the app's
 * surface by owner decision 2026-08-30, and Bulk Mail by owner decision
 * 2026-09-05 (no transport behind it; building one crosses the bridge rule,
 * AGENTS.md hard rule 14) — the routes still exist on the live Drupal desk,
 * they simply are not offered here. Do not re-propose them.
 *
 * v5 T3 moved **Course report** here from the Board's export shelf. It is a
 * centre-scoped date-range report, not a per-course sheet, and it was the one
 * cell on a twelve-cell shelf that asked a different question. Four native
 * tiles now, no desk-site chips.
 */
fun centreDeskTiles(centreId: Int): List<DeskTileSpec> = listOf(
    DeskTileSpec("Centre Settings", "centre/$centreId/edit", DeskTileAction.CentreOps),
    DeskTileSpec(
        "Course report",
        "centre/$centreId/course-report",
        DeskTileAction.CourseReport,
        isNew = true,
    ),
    DeskTileSpec("Advanced Search", "search-app/$centreId", DeskTileAction.AdvancedSearch),
    DeskTileSpec("App Settings", "", DeskTileAction.AppSettings),
)

/** The sub-line each native tile carries now that the grid buys it the height. */
fun deskTileSubLine(action: DeskTileAction?): String = when (action) {
    DeskTileAction.CentreOps -> "Rooms, hall and course defaults"
    DeskTileAction.CourseReport -> "Roll counts over a date range"
    DeskTileAction.AdvancedSearch -> "Find an applicant across courses"
    DeskTileAction.AppSettings -> "This device, sign-in and local data"
    null -> ""
}

/**
 * The phone course-hub catalogue (owner feedback 2026-08-16): native flows
 * first, in day-flow order, each with its card glyph; the desk-site links
 * (`live == null`) follow and render only inside the ⋯ overflow menu — the
 * phone opens straight into native screens, never the desk site.
 */
fun courseHubTiles(centreId: Int, courseId: Int): List<CourseHubTile> = listOf(
    CourseHubTile("View Applications", "search-course/$centreId/$courseId?s=&t=&g=&d=a", CourseHubLive.Applications, "▤"),
    CourseHubTile("Zero Day", "zero-day/$centreId/$courseId", CourseHubLive.ZeroDay, "✓"),
    CourseHubTile("Day 0 summary", "Day 0 summary", CourseHubLive.Summary, "≡"),
    CourseHubTile("Photo review", "Photo review", CourseHubLive.Photos, "◎"),
    CourseHubTile("Audit applications", "audit/$centreId/$courseId", CourseHubLive.Audit, "△"),
    CourseHubTile("Calling students", "calling/$centreId/$courseId", CourseHubLive.Calling, "✆"),
    CourseHubTile("Centre Settings", "centre/$centreId/edit", CourseHubLive.CentreOps, "⚙"),
    CourseHubTile("Add Application", "app/add/$centreId/$courseId"),
    CourseHubTile("Day 0 List", "day0-list/$centreId/$courseId"),
    CourseHubTile("Seating Plan", "seating/$centreId/$courseId"),
    CourseHubTile("Student Chit", "student-chit/$centreId/$courseId"),
    CourseHubTile("Checking Slip", "checking-slip/$centreId/$courseId"),
    CourseHubTile("Teachers List", "teacher-list/$centreId/$courseId"),
    CourseHubTile("Laundry List", "laundry-list/$centreId/$courseId"),
    CourseHubTile("Valuable List", "valuable-list/$centreId/$courseId"),
    CourseHubTile("Course Summary Report", "report-day11/$centreId/$courseId"),
)

/** The native-flow cards on the phone hub. */
fun courseHubLiveTiles(centreId: Int, courseId: Int): List<CourseHubTile> =
    courseHubTiles(centreId, courseId).filter { it.live != null }

/** Desk-site destinations, tucked into the hub's ⋯ overflow menu. */
fun courseHubDeskTiles(centreId: Int, courseId: Int): List<CourseHubTile> =
    courseHubTiles(centreId, courseId).filter { it.live == null }

/**
 * Hub overflow titles that have a Board `SheetExport`, so the phone fetches
 * the real sheet instead of the [DeskTileAction]-less placeholder.
 *
 * Since 1.39.0 `SheetViewerPane` mounts at the `DipiAppUi` root, so every
 * Board export is drawable at every window size: `Page` exports (Day 0 List,
 * Seating Plan, Student Chit, Checking Slip, Teachers List) open in the
 * in-app viewer, and `Document` exports still hand off to the system viewer
 * through `DeskUiState.openDoc`, which is collected at the top of
 * `DipiAppUi`. The Seating Plan tile reaches the native hall (5h/5i), never
 * `GET /seating`.
 *
 * `hubSheetLabelsCoverEveryBoardExport` in `CourseHubScreenTest` pins that.
 */
fun hubSheetLabel(title: String): String? = when (title) {
    "Day 0 List" -> "Day 0 list"
    "Seating Plan" -> "Seating plan"
    "Student Chit" -> "Student chit"
    "Checking Slip" -> "Checking slip"
    "Teachers List" -> "Teacher list"
    "Laundry List" -> "Laundry list"
    "Valuable List" -> "Valuable list"
    "Course Summary Report" -> "Course summary"
    else -> null
}
