package org.dhamma.dipi.staff

import android.content.Intent
import android.webkit.WebView
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockWebServer
import org.dhamma.dipi.staff.data.ConnectivityMonitor
import org.dhamma.dipi.staff.data.PhotoEditStore
import org.dhamma.dipi.staff.datastore.PhotoCorrectionStore
import org.dhamma.dipi.staff.desk.SheetStylesheet
import org.dhamma.dipi.staff.desk.hardenForSheets
import org.dhamma.dipi.staff.data.StaffRepository
import org.dhamma.dipi.staff.database.ApplicantDao
import org.dhamma.dipi.staff.database.ApplicantEntity
import org.dhamma.dipi.staff.database.OutboxDao
import org.dhamma.dipi.staff.database.OutboxEntity
import org.dhamma.dipi.staff.datastore.SessionStore
import org.dhamma.dipi.staff.model.ApplicantCard
import org.dhamma.dipi.staff.model.ApplicantId
import org.dhamma.dipi.staff.model.ApplicantStatus
import org.dhamma.dipi.staff.model.ApplicantType
import org.dhamma.dipi.staff.model.Centre
import org.dhamma.dipi.staff.model.CentreId
import org.dhamma.dipi.staff.model.Course
import org.dhamma.dipi.staff.model.CourseId
import org.dhamma.dipi.staff.model.Gender
import org.dhamma.dipi.staff.model.Session
import org.dhamma.dipi.staff.model.SheetExport
import org.dhamma.dipi.staff.model.SheetPayload
import org.dhamma.dipi.staff.model.SheetSort
import org.dhamma.dipi.staff.model.TeacherRoll
import org.dhamma.dipi.staff.network.DipiMockDispatcher
import org.dhamma.dipi.staff.network.DrupalAuthApi
import org.dhamma.dipi.staff.network.PhotoLoader
import org.dhamma.dipi.staff.network.SessionCookieJar
import org.dhamma.dipi.staff.network.StaffApi
import org.dhamma.dipi.staff.network.TokenStore
import org.dhamma.dipi.staff.ui.DeskScreen
import org.dhamma.dipi.staff.ui.DeskUiState
import org.dhamma.dipi.staff.ui.DeskViewModel
import org.dhamma.dipi.staff.ui.url
import org.dhamma.dipi.staff.ui.DipiAppUi
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import retrofit2.Retrofit
import java.io.File

/**
 * The Board export → sheet viewer loop wired through DipiAppUi against the
 * frozen repository seam: an export tap opens the in-app HTML viewer, a
 * document hands off to the system viewer, a refusal surfaces verbatim on the
 * desk snackbar, and close returns to the Board pane untouched underneath.
 *
 * The repository runs in real mock mode (MockWebServer + DipiMockDispatcher)
 * so the desk's on-open worklist fetch succeeds quietly; the sheet fetch
 * itself is stubbed via the VM's test seams to exercise each payload shape.
 */
@RunWith(RobolectricTestRunner::class)
@Config(qualifiers = "w1240dp-h844dp-land")
class SheetViewerTest {
    @get:Rule
    val rule = createComposeRule()

    private val server = MockWebServer().apply { dispatcher = DipiMockDispatcher() }

    @After
    fun tearDown() {
        server.shutdown()
    }

    private class FakeTokens : TokenStore {
        var cookie: String? = null
        var token: String? = null
        override suspend fun sessionCookie() = cookie
        override suspend fun csrf() = token
        override suspend fun saveSession(cookie: String?, csrf: String?) {
            this.cookie = cookie
            this.token = csrf
        }
        override suspend fun clear() {
            cookie = null
            token = null
        }
    }

    private class FakeApplicants : ApplicantDao {
        override fun observe(courseId: Int): Flow<List<ApplicantEntity>> = flowOf(emptyList())
        override suspend fun list(courseId: Int): List<ApplicantEntity> = emptyList()
        override suspend fun listAll(): List<ApplicantEntity> = emptyList()
        override suspend fun get(id: Int): ApplicantEntity? = null
        override suspend fun upsert(rows: List<ApplicantEntity>) = Unit
        override suspend fun clear() = Unit
    }

    private class FakeOutbox : OutboxDao {
        override fun observePending(): Flow<List<OutboxEntity>> = flowOf(emptyList())
        override suspend fun pending(): List<OutboxEntity> = emptyList()
        override suspend fun insert(row: OutboxEntity): Long = 1L
        override suspend fun updateState(id: Long, state: String, message: String?) = Unit
        override suspend fun clear() = Unit
    }

    private fun buildVm(): DeskViewModel {
        server.start()
        val app = RuntimeEnvironment.getApplication()
        val tokens = FakeTokens()
        val json = Json { ignoreUnknownKeys = true }
        val base = "http://127.0.0.1:${server.port}/"
        val retrofit = Retrofit.Builder()
            .baseUrl(base)
            .client(OkHttpClient())
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
        val sessionStore = SessionStore(app)
        val repo = StaffRepository(
            auth = retrofit.create(DrupalAuthApi::class.java),
            api = retrofit.create(StaffApi::class.java),
            tokens = tokens,
            sessionStore = sessionStore,
            courseOpsStore = testCourseOpsStore(),
            applicants = FakeApplicants(),
            outbox = FakeOutbox(),
            json = json,
            cookies = SessionCookieJar(tokens),
            useMock = true,
            baseUrl = base,
            context = app,
        )
        return DeskViewModel(
            repo,
            sessionStore,
            testCourseOpsStore(),
            PhotoEditStore(app, json),
            PhotoLoader(OkHttpClient(), true, base, server),
            PhotoCorrectionStore {
                RuntimeEnvironment.getApplication()
                    .getSharedPreferences("pc_sheet", android.content.Context.MODE_PRIVATE)
            },
            ConnectivityMonitor(app),
        )
    }

    private val centre = Centre(CentreId(12), "Dhamma Sudha")

    private fun deskState() = DeskUiState(
        screen = DeskScreen.CourseHub,
        session = Session(
            uid = 5,
            name = "registrar.sudha",
            displayName = "registrar.sudha",
            centres = listOf(centre),
            modeTest = false,
        ),
        course = Course(CourseId(77), CentreId(12), "10-Day", "2 Sep 2026", "13 Sep 2026"),
    )

    private fun card(id: Int = 31) = ApplicantCard(
        id = ApplicantId(id),
        centreId = CentreId(12),
        courseId = CourseId(77),
        givenName = "Meera",
        familyName = "Kulkarni",
        gender = Gender.F,
        status = ApplicantStatus("Confirmed"),
        type = ApplicantType.Student,
        oldStudent = false,
        attended = false,
    )

    @Test
    fun exportTapShowsLoadingThenTheHtmlViewerWithItsTitle() {
        val vm = buildVm()
        val gate = CompletableDeferred<SheetPayload>()
        vm.sheetFetch = { _, _, _, _ -> gate.await() }
        vm.seedForTest(deskState())
        rule.setContent { DipiAppUi(vm) }

        // A genuine tap on the Board export cell (scrolled into view).
        rule.onNodeWithText("Day 0 list").performScrollTo().performClick()
        rule.onNodeWithTag("sheet-viewer").assertExists()
        rule.onNodeWithTag("sheet-view-loading").assertExists()

        gate.complete(
            SheetPayload.Html("Day 0 list", "<html><body>ROLL</body></html>", "http://localhost/"),
        )
        rule.waitForIdle()
        rule.onNodeWithTag("sheet-title").assertTextEquals("Day 0 list")
        rule.onNodeWithTag("sheet-web").assertExists()
        rule.onNodeWithTag("sheet-view-loading").assertDoesNotExist()
    }

    @Test
    fun notAvailableClosesTheViewerAndShowsTheServerMessageVerbatim() {
        val vm = buildVm()
        vm.sheetFetch = { _, _, _, _ ->
            SheetPayload.NotAvailable("Course report is not available until Day 10")
        }
        vm.seedForTest(deskState())
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Course report") }
        rule.waitForIdle()
        rule.onNodeWithTag("sheet-viewer").assertDoesNotExist()
        assertEquals(
            "Course report is not available until Day 10",
            vm.state.value.snack?.text,
        )
        rule.onNodeWithText("Course report is not available until Day 10").assertIsDisplayed()
    }

    @Test
    fun documentPayloadHandsOffToTheSystemViewer() {
        val vm = buildVm()
        val app = RuntimeEnvironment.getApplication()
        val file = File(app.cacheDir, "sheets/male.pdf").apply {
            parentFile!!.mkdirs()
            writeText("pdf")
        }
        vm.sheetFetch = { _, _, _, _ -> SheetPayload.Document("Course summary", file, "application/pdf") }
        vm.seedForTest(deskState())
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Course summary") }
        rule.waitForIdle()

        val started = shadowOf(app).nextStartedActivity
        assertEquals(Intent.ACTION_VIEW, started.action)
        assertEquals("application/pdf", started.type)
        assertEquals(
            Intent.FLAG_GRANT_READ_URI_PERMISSION,
            started.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION,
        )
        assertEquals("org.dhamma.dipi.staff.fileprovider", started.data?.authority)
        // The one-shot is consumed and no in-app viewer opens for documents.
        assertNull(vm.state.value.openDoc)
        rule.onNodeWithTag("sheet-viewer").assertDoesNotExist()
    }

    @Test
    fun closeReturnsToTheBoardUnderneath() {
        val vm = buildVm()
        vm.sheetFetch = { _, _, _, _ ->
            error("Board seating must not hit sheetFetch")
        }
        vm.seedForTest(deskState().copy(teacherRoll = TeacherRoll(emptyList())))
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Seating plan") }
        rule.waitForIdle()
        rule.onNodeWithTag("sheet-viewer").assertExists()

        rule.onNodeWithText("CLOSE").performClick()
        rule.waitForIdle()
        rule.onNodeWithTag("sheet-viewer").assertDoesNotExist()
        // The Board pane is still the section underneath.
        rule.onNodeWithText("SHEETS & EXPORTS").assertIsDisplayed()
        rule.onNodeWithText("Course summary").assertIsDisplayed()
    }

    /**
     * v5 T3: Course report is a native destination on the centre dashboard,
     * not a sheet in this overlay. Opening it must not touch `sheetFetch`
     * and must not need a course.
     */
    @Test
    fun openCourseReportLeavesTheSheetViewerAloneAndNeedsNoCourse() {
        val vm = buildVm()
        var fetched = false
        vm.sheetFetch = { _, _, _, _ ->
            fetched = true
            SheetPayload.NotAvailable("never")
        }
        vm.seedForTest(deskState().copy(course = null))
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openCourseReport() }
        rule.waitForIdle()
        rule.runOnIdle {
            assertNull(vm.state.value.sheetView)
            assertNull(vm.state.value.course)
            assertEquals(DeskScreen.CourseReport, vm.state.value.screen)
            // Nothing is asked for until RUN.
            assertFalse(fetched)
            assertFalse(vm.state.value.courseReport.ran)
        }
        rule.onNodeWithTag("course-report-screen").assertExists()
    }

    @Test
    fun applicationEditOpensAuthenticatedBrowserFlowInsteadOfReadOnlyWebView() {
        val vm = buildVm()
        vm.seedForTest(deskState().copy(
            rows = listOf(card()), visible = listOf(card()),
            deskSection = org.dhamma.dipi.staff.desk.DeskSection.Applications,
            deskAppId = card().id,
        ))
        var destination: String? = null
        rule.setContent { DipiAppUi(vm, deskSiteLauncher = org.dhamma.dipi.staff.ui.DeskSiteLauncher {
            destination = it.url(); true
        }) }

        rule.waitForIdle()
        rule.runOnIdle { vm.seedForTest(deskState().copy(
            rows = listOf(card()), visible = listOf(card()),
            deskSection = org.dhamma.dipi.staff.desk.DeskSection.Applications,
            deskAppId = card().id,
        )) }
        rule.onNodeWithText("EDIT ON DESK SITE ↗").performClick()
        rule.waitForIdle()
        assertEquals("${BuildConfig.BASE_URL}/user/login?destination=app%2F31%2Fedit", destination)
        rule.onNodeWithTag("sheet-viewer").assertDoesNotExist()
    }

    /* ── v5 T1 · shared sheet chrome + injected stylesheet ────────────── */

    /**
     * JavaScript is off, so every `Columns:` pill and `Print` link on the
     * desk's own toolbar is a control drawn at full weight that does
     * nothing. The injected stylesheet hides them.
     */
    @Test
    fun injectedStylesheetHidesNoPrintFurniture() {
        val css = SheetStylesheet.render("<div class=\"no-print\">Print</div>", emptySet())
        listOf(
            ".no-print",
            ".helptext",
            ".col-toggle",
            ".remove-seat",
            ".remove-cell",
            ".store-seat-changes",
            ".dh-add-col",
            ".dh-blank-col",
            ".dh-del-col",
            ".add-row",
            ".drag-img",
        ).forEach { selector ->
            assertTrue("$selector must be hidden", css.contains(selector))
        }
        assertFalse(
            "seating cells must stay visible",
            css.contains(".ui-state-default{display:none") ||
                css.contains(".ui-state-default{display:none!important"),
        )
        assertTrue("dead furniture must be display:none", css.contains("display:none!important"))
        // Nothing that cannot be tapped may look tappable.
        assertTrue(css.contains("pointer-events:none!important"))
        // The server body is passed through, never rewritten.
        assertTrue(css.contains("<div class=\"no-print\">Print</div>"))
    }

    @Test
    fun injectedStylesheetDoesNotHideSeatingCells() {
        val css = SheetStylesheet.render("<li class=\"ui-state-default\">A1</li>", emptySet())
        assertFalse(css.contains(".ui-state-default{display:none"))
        assertTrue(css.contains("<li class=\"ui-state-default\">A1</li>"))
        assertTrue(css.contains(".day0-blockinfo"))
    }

    /**
     * The stylesheet is a UI-layer decoration. `SheetPayload.Html.html` must
     * stay byte-identical to what the desk sent, or the next agent debugging
     * a parse against a saved body will be reading our CSS.
     */
    @Test
    fun injectedStylesheetIsNotInTheTransportPayload() {
        val vm = buildVm()
        val body = "<html><body><div class=\"no-print\">Print</div>ROLL</body></html>"
        vm.sheetFetch = { _, _, _, _ -> SheetPayload.Html("Day 0 list", body, "http://localhost/") }
        vm.seedForTest(deskState())
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Day 0 list") }
        rule.waitForIdle()
        assertEquals(body, vm.state.value.sheetView?.html?.html)
        assertFalse(vm.state.value.sheetView!!.html!!.html.contains("dipi-sheet"))
    }

    /** Hiding a column is a CSS class on a body we already hold. */
    @Test
    fun columnChipTogglesWithoutARefetch() {
        val vm = buildVm()
        var fetches = 0
        vm.sheetFetch = { _, _, _, _ ->
            fetches++
            SheetPayload.Html("Day 0 list", "<table/>", "http://localhost/")
        }
        vm.seedForTest(deskState())
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Day 0 list") }
        rule.waitForIdle()
        assertEquals(1, fetches)

        rule.onAllNodesWithTag("sheet-column-chip")[0].performClick()
        rule.waitForIdle()
        assertEquals("a column chip must never cost a request", 1, fetches)
    }

    /** The order is the server's to decide, so changing it asks again. */
    @Test
    fun sortSegmentRefetches() {
        val vm = buildVm()
        val sorts = mutableListOf<SheetSort>()
        vm.sheetFetch = { _, _, _, sort ->
            sorts += sort
            SheetPayload.Html("Day 0 list", "<table/>", "http://localhost/")
        }
        vm.seedForTest(deskState())
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Day 0 list") }
        rule.waitForIdle()
        assertEquals(listOf(SheetSort.Default), sorts)

        rule.onNodeWithText("Conf no.").performClick()
        rule.waitForIdle()
        assertEquals(listOf(SheetSort.Default, SheetSort.ConfirmationNo), sorts)
        assertEquals(SheetSort.ConfirmationNo, vm.state.value.sheetView?.sort)
    }

    /**
     * The sheet's own `<div class="title">` is hidden by the stylesheet, so
     * the course line in the header is the only place it appears.
     */
    @Test
    fun sheetHeaderShowsCourseIdentityOnce() {
        val vm = buildVm()
        vm.sheetFetch = { _, _, _, _ ->
            SheetPayload.Html("Day 0 list", "<table/>", "http://localhost/")
        }
        vm.seedForTest(deskState())
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Day 0 list") }
        rule.waitForIdle()
        rule.onNodeWithTag("sheet-course-line").assertExists()
        assertTrue(vm.state.value.sheetView!!.courseLine.startsWith("10-Day"))
        assertTrue(vm.state.value.sheetView!!.courseLine.endsWith("on the roll"))
        val css = SheetStylesheet.render("<div class=\"title\">10-Day</div>", emptySet())
        assertTrue("the sheet's own title block is hidden", css.contains(".header-day0 .title"))
    }

    /** The seating plan is read + print here: the desk's editor is JavaScript. */
    @Test
    fun seatingPlanChipReadsReadAndPrint() {
        val vm = buildVm()
        vm.sheetFetch = { _, _, _, _ ->
            error("Board seating must not hit sheetFetch")
        }
        vm.seedForTest(deskState().copy(teacherRoll = TeacherRoll(emptyList())))
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Seating plan") }
        rule.waitForIdle()
        rule.onNodeWithTag("sheet-viewonly-chip").assertTextEquals("READ & PRINT")
        rule.onNodeWithTag("hall-body").assertExists()
        rule.onNodeWithTag("sheet-web").assertDoesNotExist()
        rule.onNodeWithTag("sheet-print").assertDoesNotExist()
        // No alternate order on this sheet: the desk's only parameter here is
        // the forbidden `r`.
        rule.onNodeWithTag("sheet-sort").assertDoesNotExist()
    }

    /** Native 5h: the Board chip never GETs `/seating`. */
    @Test
    fun seatingPlanNeverHitsSheetFetch() {
        val vm = buildVm()
        var fetched = false
        vm.sheetFetch = { _, _, _, _ ->
            fetched = true
            SheetPayload.Html("Seating plan", "<table/>", "http://localhost/")
        }
        vm.seedForTest(deskState().copy(teacherRoll = TeacherRoll(emptyList())))
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Seating plan") }
        rule.waitForIdle()
        rule.runOnIdle {
            assertFalse(fetched)
            assertTrue(vm.state.value.sheetView!!.nativeHall)
            assertNull(vm.state.value.sheetView!!.html)
        }
        rule.onNodeWithTag("hall-body").assertExists()
    }

    /** 5i: a roll with seats gives the native hall a real PRINT button. */
    @Test
    fun seatingPlanWithARollShowsThePrintButton() {
        val vm = buildVm()
        val roll = TeacherRoll(
            listOf(
                org.dhamma.dipi.staff.model.RollGroup(
                    at = "Uma Rangan", code = "URN", gender = Gender.M,
                    seniority = org.dhamma.dipi.staff.model.RollSeniority.OLD,
                    group = "1", total = 1,
                    rows = listOf(
                        org.dhamma.dipi.staff.model.RollRow(
                            sn = 1, name = "Alice Kumar", room = "Mbk-1", age = "40", city = "Pune",
                            courses = emptyList(), cell = "", seat = "A1",
                            seatKind = org.dhamma.dipi.staff.model.SeatKind.FLOOR,
                            backrest = false, occupation = "", education = "", languages = "",
                        ),
                    ),
                ),
            ),
        )
        vm.seedForTest(deskState().copy(teacherRoll = roll))
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Seating plan") }
        rule.waitForIdle()
        rule.onNodeWithTag("sheet-viewonly-chip").assertTextEquals("READ & PRINT")
        rule.onNodeWithTag("sheet-print").assertExists()
    }

    @Test
    fun day0SummaryPrintsFromTheSheetHeader() {
        val vm = buildVm()
        vm.sheetClock = { "09:41" }
        vm.sheetFetch = { _, _, _, _ ->
            SheetPayload.Summary("Day 0 summary", org.dhamma.dipi.staff.model.DaySummary())
        }
        vm.seedForTest(deskState())
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Day 0 summary") }
        rule.waitForIdle()
        rule.onNodeWithTag("sheet-print").assertExists()
        rule.onNodeWithTag("sheet-freshness").assertTextEquals("FROM THE DESK · 09:41")
        rule.onNodeWithTag("sheet-web").assertDoesNotExist()
    }

    @Test
    fun teacherListOffersCityAndEducationChips() {
        val vm = buildVm()
        vm.sheetFetch = { _, _, _, _ ->
            SheetPayload.Html("Teacher list", "<table/>", "http://localhost/")
        }
        vm.seedForTest(deskState())
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Teacher list") }
        rule.waitForIdle()
        rule.onNodeWithText("City").assertExists()
        rule.onNodeWithText("Education").assertExists()
    }

    /**
     * These pages carry health disclosures and contact data. The hardening
     * is not decoration — pin it so a future "just enable JS for the
     * toolbar" cannot land quietly.
     */
    @Test
    fun injectedPrintCssLaysStudentChits12UpAndCheckingSlip2Up() {
        val chit = SheetStylesheet.render(
            "<div class=\"table-student-chit\"></div>",
            emptySet(),
            SheetExport.StudentChit,
        )
        assertTrue(chit.contains("dipi-student-chit"))
        assertTrue("12-up cell width", chit.contains("63.3mm"))
        assertTrue("12-up cell height", chit.contains("69.3mm"))
        assertFalse("9-up height must not win", chit.contains("92.3mm"))
        assertTrue(chit.contains("html.dipi-student-chit .table-student-chit"))
        assertTrue(
            "Contact stays off on paper",
            chit.contains("@media print{.d0-contact{display:none!important}}"),
        )
        val slip = SheetStylesheet.render(
            "<div class=\"table-student-chit\"></div>",
            emptySet(),
            SheetExport.CheckingSlip,
        )
        assertTrue(slip.contains("dipi-checking-slip"))
        assertTrue("5g 2-up width", slip.contains("190mm"))
        assertTrue("5g 2-up height", slip.contains("138.5mm"))
        assertTrue(slip.contains("TIME  AM / PM"))
        assertEquals(
            android.print.PrintAttributes.MediaSize.ISO_A4,
            org.dhamma.dipi.staff.ui.NativePrint.a4Attributes().mediaSize,
        )
        assertEquals(
            android.print.PrintAttributes.MediaSize.ISO_A4.asLandscape(),
            org.dhamma.dipi.staff.ui.NativePrint.a4LandscapeAttributes().mediaSize,
        )
    }

    /* ── M1 · the viewer mounts at the DipiAppUi root, so the phone draws it ── */

    @Test
    @Config(qualifiers = "w411dp-h891dp")
    fun phoneOpensAPageSheetInTheViewerAndCloseReturnsToTheHub() {
        val vm = buildVm()
        vm.sheetFetch = { _, _, _, _ ->
            SheetPayload.Html("Day 0 list", "<html><body>ROLL</body></html>", "http://localhost/")
        }
        vm.seedForTest(deskState())          // screen = CourseHub; 411dp → phone branch
        rule.setContent { DipiAppUi(vm) }

        rule.runOnIdle { vm.openSheet("Day 0 list") }
        rule.waitForIdle()
        rule.onNodeWithTag("sheet-viewer").assertExists()
        rule.onNodeWithTag("sheet-web").assertExists()

        rule.runOnIdle { vm.back() }         // back closes the overlay first
        rule.waitForIdle()
        rule.onNodeWithTag("sheet-viewer").assertDoesNotExist()
    }

    @Test
    @Config(qualifiers = "w411dp-h891dp")
    fun phoneHubOverflowTileOpensThePageSheetViewer() {
        val vm = buildVm()
        vm.sheetFetch = { _, _, _, _ ->
            SheetPayload.Html("Day 0 list", "<html><body>ROLL</body></html>", "http://localhost/")
        }
        vm.seedForTest(deskState())
        rule.setContent { DipiAppUi(vm) }

        // The hub overflow tile → sheet route, end to end on the phone.
        rule.onNodeWithContentDescription("Desk site links").performClick()
        rule.onNodeWithText("Day 0 List").performClick()
        rule.waitForIdle()
        rule.onNodeWithTag("sheet-viewer").assertExists()
        rule.onNodeWithTag("sheet-web").assertExists()
    }

    @Test
    fun javaScriptStaysDisabled() {
        val webView = WebView(RuntimeEnvironment.getApplication())
        webView.hardenForSheets()
        assertFalse("JavaScript must stay off in the sheet viewer", webView.settings.javaScriptEnabled)
        assertFalse(webView.settings.domStorageEnabled)
        assertFalse(webView.settings.allowFileAccess)
        assertFalse(webView.settings.allowContentAccess)
    }
}
