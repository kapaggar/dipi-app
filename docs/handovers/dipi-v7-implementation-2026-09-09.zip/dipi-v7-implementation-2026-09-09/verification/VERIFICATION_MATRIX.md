# Verification matrix

All checks below are **planned**, not passed. The implementing agent records results in `STATUS_TEMPLATE.csv`, adding evidence paths and exact commands. Keep synthetic fixtures in tests/debug-only test environments; do not add a fixture picker to the production app.

## Fixed fixtures and reproducible populations

Use existing fixture constructors from the relevant tests. Allocate independent centre/course IDs for each case. Use names such as “Synthetic Applicant 01”, `.test` email domains, and non-dialled marker phone strings. Tests never invoke dial/send endpoints. No live ID document, device PIN, health answer or photo belongs in test output. Health snippets below are invented classification inputs, not real disclosures.

**F-ROOM:** Inventory contains Male/Mbk codes `Mbk 1` through `Mbk 4`, Male/Guest codes `Guest 1` and `Guest 2`, and Female/Fbk codes `Fbk 1` and `Fbk 2`. Use these synthetic rows and local records:

| Applicant ID | Conf | Server status | Local checkedIn | Local room |
| ---|---|---|---|---|
| 1 | OM1 | Confirmed | true | Mbk 1 |
| 2 | NM2 | Confirmed | true | Mbk 2 |
| 3 | OM3 | Expected | false | Mbk 3 |
| 4 | OM4 | Left | true (stale) | Mbk 4 |
| 5 | OM5 | Confirmed | true | Guest 1 |
| 6 | NF6 | Confirmed | true | Fbk 1 |

Expected total/occupied/free: Mbk 4/2/2, Guest 2/1/1, Fbk 2/1/1. Use exact inventory strings including spaces. In a separate variant, change applicants 1 and 2 to share `Mbk 1`: Mbk occupied becomes 1 and free becomes 3; do not silently erase the assignment conflict if existing code reports it. An unknown room `Missing 99` does not occupy a configured room.

**F-ARRIVAL:** 15 Male Old roll rows OM1..OM15; 1–13 effectively checked in, 14 pending, 15 Left. All 15; eligible 14; arrived 13; pending 1; Left 1. Give every row a phone for the call fixture. No outcomes: To call 14; All 15; held-out 1. After logging one eligible row Confirmed: backlog 13; logged 1; All 15. The name search can narrow the applicant scope, but Old/New/search/status cannot change full-course room occupancy.

**F-BOARD:** A complete roll with 71 `ApplicantType.Student` and 11 `Sevak`,82 total. Choose attendance and Left explicitly; derive expected counts from the fixture list, not v7's contradictory sample summary. Include an unknown confirmation prefix and an additional supported status to prove roll membership does not silently become only Expected/Confirmed. No hardcoded 82/71/11 in production.

**F-HEALTH:** six canonical labels with values `""`, `"-"`, `"No"`, invented multi-paragraph text, `"Yes - source narrative"`, `"Yes"`. Female: 4 recorded / 2 not provided; the prefix narrative is RECORDED. Male with all blank: 0 recorded / 5 not provided / 1 N/A. Secondary inputs: whitespace, en-dash, mixed-case exact YES/no, “No longer …”, “Yesterday …”, “Not applicable”, very long body. Render source values exactly.

**F-HISTORY:** (a) all ten numeric source keys 0; (b) one positive key; (c) missing one key; (d) nonnumeric key; (e) legacy encrypted snapshot without provenance field; (f) first/last metadata literal Unknown. Only (a) auto-collapses. The model/parser must not pretend missing source cells prove 0.

**F-AUDIT:** Two active distinct IDs with equal normalized phone; two different surnames with shared email; duplicate confirmation number; same name+DOB without phone; a third inactive Duplicate; one server-only finding without structured relation; ten and 100 affected subjects; two applicants with identical display name but distinct IDs. Preserve current ACTIVE rules; inactive Duplicate is not manufactured as an active match. Each Open must resolve by ID.

**F-PRINT:** 25 chits, 5 checking slips, two hall rolls with enough rows to test trimmed trailing empties and occupied CW/CH rail, Day 0 list with unique synthetic Contact marker, Manager list with a different allowed contact marker, a long comment/health field, report with named synthetic conducting/assisting teachers. Use actual Android print-to-PDF output.

## Model, source, and population checks

| Case | Action/input | Required result | Evidence/test home |
| ---|---|---|---|
| H01 | Blank, absent label, whitespace, '-' and en-dash | NOT_PROVIDED; no inferred No; dash source text distinct from absence | HealthAnswerPresentationTest + StudentCardScreenTest |
| H02 | Exact Yes/No, any case/outer whitespace | Explicit badge; original body preserved | HealthAnswerPresentationTest |
| H03 | Yes-prefix, No-prefix, Yesterday, arbitrary text | RECORDED; no clinical inference or danger color | Model test + T3 screenshot |
| H04 | Male Pregnancy, including unexpected source text | App-authored N/A; source distinct; excluded from recorded/missing counts; six total | Model/UI tests |
| H05 | Partial cached card and all-six-empty card | Exactly six canonical positions; 0/6 or 0/5/1 summary, no missing cards | StudentCardScreenTest |
| H06 | Nonempty No in MED and existing flag scenarios | Badge No; flags retain existing presence/PREG/MONK semantics | ApplicationCardTest + UI test |
| H07 |2000-character invented answer, 1.3× and 412dp | Full text reachable, no per-answer scroll/clipping or logging | Screenshot + semantics + manual scroll |
| H08 | Serialize/decode card, logout/course change/erase | Private encrypted cache only; redacted string output; existing wipe rules | CourseOpsStoreTest + SessionExpiryTest |
| H09 | F-HISTORY complete zero, positive, missing, invalid, legacy | Only complete zero collapses; expanded ten-key order; Unknown retained | Parser/store/model/UI tests |
| R01 | F-ROOM across Old/New/search/status filters | Mbk free 2/4 stable; Guest and Fbk independent | DeskScopeTest + DeskPanesTest |
| R02 | F-ARRIVAL switch To arrive/Arrived/Left/All | Counts 13 arrived, 1 pending, 1 Left, 14 eligible; All 15; exact Left status unchanged | DeskDeriveTest + UI |
| R03 | Pre-arrival room string, Left stale local record | Neither occupies; no action enabled for Left | FinalizedRooms/DeskScope tests |
| R04 | Finalized flags, historical Attended room, Left | Historical allocation shown; no sync/edit; no dates heuristic; ZeroDay skipped | FinalizedRooms/Actions tests |
| R05 | Two occupants same code, unknown code, empty/missing inventory | Unique physical-room count; no negative free; unavailable distinct from zero | DeskScopeTest |
| R06 | Switch block in Check-in then Room Chart; change course | Shared valid block selected; focus reset; no cross-course stale selection | DeskNavTest + RoomsPaneTest |
| R07 | Physical list 2,10,A; first/last/no occupied; invalid jump | Exact physical traversal with wrap, disabled empty action, no fuzzy/wrong-block jump | RoomNavigationTest |
| R08 | Long names, age, all-empty/mixed rows, configured 1/4/7/12 columns |17sp Medium; 12sp top-right age once; physical order/config retained; content reachable | RoomsPaneTest + D6 screenshots |
| Q01 | F-ARRIVAL phone-bearing call round | To call 14/All 15/held out 1; outcome changes backlog only | DeskDerive/CallingScreen tests |
| Q02 | Left no phone, historical outcomes, legacy Reached/Call back | Counts truthful; old records preserved; no new outcomes invented | DeskDerive/CallingScreen tests |
| Q03 | Open All, select filters, enter WhatsApp preparation | No recipients silently added; no send or delivery/status call | WhatsAppHandoff/selection regression |
| B01 | F-BOARD with Left and additional supported status | All labels name actual population; numbers derive current roll; percentages defined at 0 | BoardPane/DeskScope tests |
| B02 | Board and rail after check-in, outcome, refresh | Relevant counts update together; audit findings distinct from affected people | BoardPane/DeskNav tests |
| B03 | Board exports and phone-only Valuable | Nine Board tiles/order unchanged; Course report on centre; formats truthful | BoardPane/SheetPresentation tests |

## Audit and navigation checks

| Case | Action/input | Required result | Evidence/test home |
| ---|---|---|---|
| A01 | Client duplicate rules on F-AUDIT | Related IDs match existing predicates and ACTIVE logic; no inference from detail | AuditRelatedApplicantsTest |
| A02 | Server-first merge with client relation | Server message unchanged; missing relation supplemented only when same rule supports it | Core audit merge tests |
| A03 | Known pair, missing partner, cross-course unstructured finding | Allowed fields only; no fabricated partner; unavailable text; totals not doubled | DeskDerive/DeskPanes tests |
| A04 |10/100 people, long explanation and email, 1.3× | Every subject reachable; evidence wraps; separate labelled Open per ID | D3 screenshots + scrolling UI test |
| A05 | Open each of two out-of-filter applicants | Correct exact ID/card each time; existing pin retained; no status write | AuditNavigationContextTest |
| A06 | Back to Audit; finding removed by refresh | Original finding/scroll if present; honest current list if removed | Navigation tests |
| A07 | Normal selection, explicit filter change, course/logout | Context/pin cleared only at intended lifecycle boundaries | DeskNav/SessionExpiry tests |
| A08 | External Edit then return | Separate browser session; once refresh; same applicant if present; updated audit | DeskSiteHandoffTest |

## Course ops, centre, report, and settings checks

| Case | Action/input | Required result | Evidence/test home |
| ---|---|---|---|
| T01 | All/group selection, empty group, failure/loading | N in view/M overall; real groups only; empty differs from failed/not loaded | TeacherListScreenTest |
| T02 | Group/hall/theme changes and Back | No extra teacher-list fetch; existing prefetch behavior | TeacherCardPrefetch/CourseOpsNav tests |
| T03 | Mixed hall roll/grid/rail/unseated/sevaks | Labelled counts; sevaks included in tally, excluded from drawn unseated list; reasons not invented | SeatGrid/SeatingPlan tests |
| T04 | Hall orientation, CW-A1, chairs, backrest | Teacher at bottom, letters columns, vertical occupied rail, current fills/bar preserved | T2 screenshots + SeatingPrintTest |
| T05 | List→card and seat→card, prev/next at group ends | Same source record; correct origin/Back; no wrap; correct disabled actions | CourseOpsNav/StudentCard tests |
| T06 | Long facts/history, no photo, first/last teachers | Facts/answers scroll; placement beside photo; allowlist/hidden fields retained | StudentCard/TeacherIdMapping tests |
| T07 | PIN empty/wrong/cancel/success; logout then return | Gate behaves; no leaked digits; encrypted PIN survives logout; erase tested on disposable fixture only | PinGate/TabletMode/store tests |
| C01 | Centre initial viewport at 1280dp, 4 upcoming+4 older | Report NEW/App/Centre Settings reachable; 2×2 older server order; single below-header scroll | CentreScreenWide/OlderCourseLimit tests |
| C02 | Many centres, long labels, 412dp/1.3× | Header bounded; all matrix rows/actions reachable; no nested scroll trap | Centre screenshots/tests |
| C03 | External Advanced Search | Existing exact browser URL; no new POST/search engine or cookie transfer | DeskSiteHandoffTest |
| C04 | Hall/room settings steppers at bounds and toggle descriptions |48dp targets, bounds enforced, correct hall callback; local save behavior unchanged | CentreOpsScreenTest |
| D01 | Blank/partial/invalid/leap/reversed/equal report dates | Valid equality allowed; invalid Run disabled and VM makes no request | ReportDateRange/CourseReportRun tests |
| D02 | This month/year/last 12 at fixed local date | Exact documented inclusive dates; preset fills; no auto-request | Model/UI/repository-spy tests |
| D03 | First open, repeated Run, editing during run, centre change | No first-open fetch; one Run; result labelled submitted range; stale session result discarded | CourseReportRunTest |
| D04 | Many courses, long teachers, empty range, refusal | Head/body/footer aligned; actual totals/teachers; true empty state; server refusal verbatim | CourseReportScreen/CSVParser tests |
| S01 | Null/invalid/future/valid lastSync at fixed now | Unknown or clock warning truthful; absolute/relative never invented | FreshnessText/Settings tests |
| S02 | Asia/Kolkata/Los_Angeles incl DST; time-only teacher cache | Actual timezone; no inferred date/age fromHH: mm | FreshnessText + display tests |
| S03 | Physical network×simulation truth table | Effective OR preserved; simulation immediate; reasons distinct; toggling off does not fake reconnection | SimulateOffline/SyncBanners tests |
| S04 | Long descriptions, Diagnostics expand/collapse, mode/theme | No clipped prose; Diagnostics grouping only; no auth/storage behavior change | SettingsScreenTest + S1 screenshot |
| S05 | Real offline/queued/expiry, desk vs Course ops |38dp/56dp layout behavior; no Course-ops queue; cached/unknown states truthful | SyncBanners/SessionExpiry tests |

## Screen, accessibility, and print checks

| Case | Action/input | Required result | Evidence/test home |
| ---|---|---|---|
| V01 | Semantic text roles all 5 light palettes+Steel night | Actual composited contrast meets target; fixed danger/status unchanged | ReadableTokens/DarkTokens/Skin tests + ratioCSV |
| V02 | Back/prev/next/Open/tabs/steppers/PIN controls |48dp target and no neighbor overlap; action hits correct target; selected/disabled announced | Bounds+interaction tests + TalkBack |
| V03 |1280×900 baseline native window, 1.0× | All main frames match approved geometry within native constraints; no prototype shell |14 main frame screenshots |
| V04 | Same width 1.3× system font | Wrapping/growth; no clipped health, scope, settings or report controls | S2 screenshots + responsive tests |
| V05 |412/599/600/900dp and keyboard | Phone routes/full sheet chrome retained; cards/filters/controls accessible; breakpoint stable | S3 screenshots + responsive tests |
| V06 | Dark from saved Blossom then return Light | Canonical Steel night; Blossom restored; no unreadable light-only Industry text | S4-reconciled screenshots + theme tests |
| P01 | Fit/Readable on HTML sheet, close/reopen, switch export | Readable cap/fit correct; choice per export; no new request or changed sort/columns | SheetViewer/SessionStore tests |
| P02 | Phone sheet controls and pinch zoom | Full existing controls reachable; native hall remains native |412dp device evidence + SheetViewer tests |
| P03 |25 chits via Android print-to-PDF | A4portrait, 3 pages, 12/12/1, correct order/no clipped text | Inspected PDF + page render |
| P04 |5 checking slips via Android print-to-PDF | A4portrait, 3 pages, 2/2/1; screen viewport count irrelevant | Inspected PDF + page render |
| P05 | Two-hall native seating print | A4landscape, teacher bottom, trimmed empties, vertical rail, one gender/page for fixture | Inspected PDF + SeatingPrintTest |
| P06 | Day0contact shown on screen then print; Manager print | Day0marker absent from print; allowed Manager marker retained | Extracted PDF text + rendered pages |
| P07 | Same content/columns in Fit vs Readable print | Same paper/orientation/pagination/content; width preference screen-only | Two actual PDFs compared |
| P08 | Long comments/answers, report teachers, 0row report | No print text truncation; report facts correct; empty-range not ghost course | PDFs + CSV parser test |
| P09 | Sort/columns/width/print and binary export routes | Only allowlisted queries; no r; no seating fetch; externalPDF/Excel behavior retained | SheetRouteSafety/SheetTransportSave tests |
| P10 | Loading/print disabled, cancel, no viewer, logout/expiry | Truthful states; no unsafe workaround; sheet cache cleared per policy | SheetViewer/lifecycle tests + device |
| P11 | Print label before Android layout | Format/packing only; no invented 3 pages/repeated-head guarantee | UI test + D7 screenshot |
| X01 | Full supported suite and lint | New changes introduce no failures; actual executed/skipped counts recorded | Gradle XML/HTML and command logs |
| X02 | Versioned debug/release artifacts and target device | Unique correct version, hashes, mock flag verified, no unintended downgrade/data wipe | APK metadata + install result |
| X03 | Final diff vs packaged source | Baseline edits preserved; no unrelated changes, prohibited routes/data or prototype code | Reviewed diff + evidence ledger |

## Device and evidence capture protocol

1. Use a dedicated test/emulator environment for synthetic data and erase/logout/cache-loss scenarios. Preserve the live registrar installation and local data. Do not install same-package mock APK over it merely to obtain screenshots.
2. Record APK SHA256/version/build mode, Android OS/WebView version, window size/density/font scale, skin/theme, fixture ID, route/selection, and capture time. Device pixels are notdp; record both. Primary design canvas 1280×900dp does not include an extra prototype sidebar in the app.
3. Capture main frames C1,C2,C3,D1,D2,D3,D4,D5,D6,D7,T1,T2,T3,S1 as appropriate. There are 14 primary frames (3+7+3+1), plus S2–S4 adaptation frames, 17 total. Cover dark Settings/card/RoomChart/hall and large-text card/Check-in/Settings/report. Additional screenshots show scroll end, errors, and unusual states rather than repeating identical frames.
4. At minimum use width 412,599,600,900,1280dp in layout tests. On physical Pixel C inspect actual shipped density/window and 1.0/1.3 font scales. If device settings are temporarily changed for testing, restore the previous settings afterwards; use a test device for disruptive changes.
5. Suggested filenames: `T3-health-mixed-blossom-1280-fs1.0.png`, `D5-arrivals-left-1280-fs1.3.png`, `D6-mbk-long-names-steel-night.png`, `P03-chits-25.pdf`, `P04-slips-5.pdf`, `P07-day0-fit.pdf`, `P07-day0-readable.pdf`. Use only synthetic content in shareable artifacts.
6. Keep screenshot/PDF provenance and verification conclusions in a small CSV. A file existing does not mean it was visually inspected. For each PDF record page count and media box; render and inspect each page. PortraitA4≈595×842points; landscape≈842×595, allowing platform rounding.12-up/2-up assertions refer to complete fixture records per printed page.
7. Android print framework may not repeat arbitrary HTML group headers or produce the page count implied by desktop CSS. Record actual behavior and correct app-generated CSS if the locked format regressed; do not add false labels or disable hardening to imitate the prototype.
8. Test errors using mocks. Use request spies/counts for absence of new writes and teacher polling; do not capture full live request/response bodies containing credentials or student data. Include method/route and request count only in shared evidence.

## Final evidence report format

For each requirement record `status`, `implemented_files`, `test_command`, `result`, `artifact_paths`, `decision_id`, and `remaining_gap`. Allowed status vocabulary: PASS, FAIL, BLOCKED_EXTERNAL, PRESERVED_VERIFIED, EXCLUDED_OPTIONAL, NOT_RUN. A reconciled requirement is PASS only for the documented resolved behavior with evidence. Missing device access is BLOCKED_EXTERNAL, never PASS.

Report total automated tests executed/passed/failed/skipped, exact commands, APK version/hash, device result, PDF checks, and optional exclusions. Existing failures must be identified with baseline evidence. Do not downgrade a failed mandatory check to “optional” after implementation to finish the task.
