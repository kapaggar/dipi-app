# Baseline and source selection

- Original repo: `/Users/wizops/DIPI/dipi-app`.
- Remote: `git@github.com:kapaggar/dipi-app.git` (access may be private).
- Commit: `64db74e549be55b4061004ab1503323a1ecd11f6`,1.46.1.
- Actual tree at packaging: 1.46.3, versionCode 97. Source manifest covers 377 tracked files, 4,660,095bytes.
- Original design ZIP: `DIPI Staff centre-registrar desk.zip`.
- Design SHA256: `815a0e243beef3c5f02b1f3389a0d7dd9fef2d877c44ae50e096805fba2679e7`.

## Preferred: existing current checkout

Inspect `git status --short` and compare relevant files against the package hashes. Keep all existing changes. Use included sources as reference when the checkout has moved on. Do not overwrite newer code with the snapshot or reset to the recorded commit.

The 12 pre-existing modified tracked files are:

```text
AGENTS.md
CLAUDE.md
app/build.gradle.kts
app/src/main/kotlin/org/dhamma/dipi/staff/ui/DeskViewModel.kt
app/src/main/kotlin/org/dhamma/dipi/staff/ui/DipiAppUi.kt
app/src/test/kotlin/org/dhamma/dipi/staff/DeskDeriveTest.kt
app/src/test/kotlin/org/dhamma/dipi/staff/DeskPanesTest.kt
docs/DESIGN.md
feature/desk/src/main/kotlin/org/dhamma/dipi/staff/desk/ApplicationsPane.kt
feature/desk/src/main/kotlin/org/dhamma/dipi/staff/desk/AuditPane.kt
feature/desk/src/main/kotlin/org/dhamma/dipi/staff/desk/DeskDerive.kt
feature/desk/src/main/kotlin/org/dhamma/dipi/staff/desk/RoomsPane.kt
```

Baseline diff: 198 insertions/62deletions. Existing untracked photo-correction handovers were not copied or changed. Packaging-created files naturally appear in the captured status; they are not source implementation changes.

## Alternative: fresh clone with history

In a new clean checkout, fetch the recorded commit and inspect the supplied patch. Run `git apply --check` before `git apply` using the absolute path to `baseline/working-tree.patch`. This reproduces the tracked 1.46.3 tree. Do not apply the patch if those changes are already present. Check all reproduced file hashes against `baseline/source-manifest.json`. Use `codex/` prefix for a new branch. No push/publication is implied.

## Alternative: included source snapshot

Work in a **copy** of `source/`; keep the packaged snapshot immutable as reference. It has current files and Gradle wrapper but no Git history. Restore executable permission with `chmod +x gradlew` if the extraction tool drops it. Configure the local Android SDK path normally without committing local.properties. A new Git repository is optional if history is needed for implementation review; do not pretend that a locally initialized repository already has the recorded upstream commit.

The package's outer plan and conflict register govern the v7 proposal. Older plans inside `source/docs/` explain history and tests; instructions in them do not silently expand the task.

## Toolchain and test baseline

Versions are pinned in `source/gradle/libs.versions.toml`. The project documents JDK 20 at `/Library/Java/JavaVirtualMachines/jdk-20.jdk` on the original host and JVM target 17. Verify installed tools rather than installing/upgrading them during planning. Current Android SDK path is documented in project instructions; local.properties intentionally stays out of this package.

No baseline Android tests were run to create this package. Existing test files are present, not certified green. The implementing agent must run the baseline and final gates in the plan. The source snapshot and package integrity were checked independently of app behavior.
