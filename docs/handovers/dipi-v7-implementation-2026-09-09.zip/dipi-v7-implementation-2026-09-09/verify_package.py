#!/usr/bin/env python3
"""Read-only integrity check for this handover; does not build or execute app/design code."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
errors = []
checked = 0
for line in (ROOT / 'MANIFEST.sha256').read_text().splitlines():
    if not line.strip():
        continue
    expected, name = line.split('  ', 1)
    rel = PurePosixPath(name)
    if rel.is_absolute() or '..' in rel.parts:
        errors.append(f'Unsafe manifest path: {name}')
        continue
    path = ROOT / name
    if path.is_symlink() or not path.is_file():
        errors.append(f'Missing or nonregular file: {name}')
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        errors.append(f'Checksum mismatch: {name}')
    checked += 1
source_entries = json.loads((ROOT / 'baseline/source-manifest.json').read_text())
for item in source_entries:
    rel = PurePosixPath(item['path'])
    if rel.is_absolute() or '..' in rel.parts:
        errors.append(f'Unsafe source path: {rel}')
        continue
    path = ROOT / 'source' / rel
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
        errors.append(f'Source snapshot mismatch: {rel}')
if errors:
    print('\n'.join(errors), file=sys.stderr)
    raise SystemExit(1)
print(f'PASS: {checked} packaged files and {len(source_entries)} source snapshots verified.')
print('This checks package integrity only. Android implementation/tests/device/print checks are not run.')
