# DIPI Staff v7 implementation handover

Prepared 2026-09-09. This package contains an implementation plan and an exact source snapshot, not an implemented v7 app.

1. Verify integrity: `python3 verify_package.py` from this package directory.
2. Give `AGENT_PROMPT.md` to the implementing AI and attach this entire ZIP.
3. Read `DECISIONS_AND_CONFLICTS.md`, then `IMPLEMENTATION_PLAN.md`, `REQUIREMENTS.csv`, and `verification/VERIFICATION_MATRIX.md`.
4. Inspect `design/DIPI Staff v7 Handoff.dc.html` and `design/DIPI Staff v7.dc.html`.
5. Select the correct source baseline using `BASELINE.md` before editing.

## Contents

- `AGENT_PROMPT.md`: copy-ready implementation instruction.
- `IMPLEMENTATION_PLAN.md`: 18 ordered tasks, exact source paths, proposed interfaces, logic/test examples, commands, and release/acceptance gates.
- `DECISIONS_AND_CONFLICTS.md`: 30 reconciliations between prototype, current code and owner rules.
- `REQUIREMENTS.csv`: full frame/requirement coverage with priority, task and verification mapping.
- `verification/VERIFICATION_MATRIX.md`: reproducible synthetic cases, screen/device/print matrix and evidence rules.
- `verification/STATUS_TEMPLATE.csv`: every requirement starts NOT_RUN; the executor fills actual results.
- `reference/OFFICIAL_REFERENCES.md`: official Android/W3C support for accessibility and printing checks.
- `reference/*.txt`: searchable text extracted from latest HTML; dynamic examples are best read in the HTML browser.
- `design/`: latest v7 prototype/handoff, DeskRail component and local preview runtime.
- `source/`: 377 tracked repository files copied from the current working tree, with existing 1.46.3 edits. No `.git`, local.properties, build outputs, keystores, or unrelated untracked handovers.
- `baseline/`: original design archive hash, source hash manifest, original commit, working-tree diff and status.
- `MANIFEST.sha256`, `verify_package.py`: packaged file-integrity checks.

## Preview the design

From this package directory:

```bash
python3 -m http.server 8767 --bind 127.0.0.1 --directory design
```

Open [v7 prototype](http://127.0.0.1:8767/DIPI%20Staff%20v7.dc.html) and [v7 handoff](http://127.0.0.1:8767/DIPI%20Staff%20v7%20Handoff.dc.html). Use another free port if 8767 is already in use. Stop the server with Ctrl-C. Local components are included; Google Fonts are an external preview dependency. The runtime contains optional CDN integration for other component types; native Android implementation must use existing app fonts/libraries, not this runtime.

The main prototype includes 17 frames: C1–C3, D1–D7, T1–T3, S1–S4. Source code and all frame notes were inspected for this handover; C1/T3/D7 were also opened in a browser, with T3 visually inspected. No Android implementation tests or device/print verification were performed during planning.

## Scope of the ZIP

The original 143-file design archive also contained older v4/v5/v6 packages, historic exports and screenshots. Those duplicates and original student screenshots/PIN-bearing legacy reference material are not repackaged. Latest v7 pages are copied byte-for-byte. Existing tracked source/test/reference files are included as developer material, not a new sanitized production dataset. Use fresh synthetic records for implementation evidence. The original archive is unchanged and identified bySHA256 in `baseline/`.

This is self-contained for source and design context. It does not include Git history, the immutable backend repository, Android SDK/JDK/Gradle dependency caches, credentials, a device, or a provisioned service. Builds still require the normal Android toolchain and dependency access.
